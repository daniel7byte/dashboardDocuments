<?php
define("LANG", 'EN');
define("HOME", 'Home');
define("DOCUMENTS", 'Documents');
define("CATEGORY", 'Category');
define("USERS", 'Users');

define("File", 'File');
define("Enter", 'Enter');
define("All", 'All');

// Btn
define("Create", 'Create');
define("Update", 'Update');

define("User", 'User');
define("Password", 'Password');

define("Edit", 'Edit');
define("Delete", 'Delete');

define("NOW", 'Now');
define("ChangePassword", 'Change password');
define("SignOff", 'Sign off');

define("Date", 'Date');
define("Actions", 'Actions');

define("Permissions", 'Permissions');
define("Name", 'Name');
define("Nick", 'Nickname');

// Priority
define("Critical", 'Critical');
define("High", 'High');
define("Medium", 'Medium');
define("Low", 'Low');

// Type
define("tPUBLIC", 'Public');
define("tPRIVATE", 'Private');

// Forms
define("Description", 'Description');
define("Privacy", 'Privacy');
define("Priority", 'Priority');